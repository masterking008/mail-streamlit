# E-Cell Mail App

## Setup

1. Create virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Run the app:
   ```bash
   ./activate.sh
   ```# mail-streamline
